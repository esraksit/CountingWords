import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

public class LinkedList {

	public static void main(String[] args) throws IOException {

		FileReader reader = new FileReader();
		String inputText="input.txt";
		String outputText="named.out.txt";
		reader.read(inputText);
		

	
	}

}
