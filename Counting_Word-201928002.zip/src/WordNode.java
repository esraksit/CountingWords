
public class WordNode {

	public String data;
	public  WordNode next;
	public int freq;
	
	
	public WordNode(String data,int val) {
		this.data=data;
		this.next=null;
		freq=1;
	}

}
